# Image Grid - Gallery

A Pen created on CodePen.

Original URL: [https://codepen.io/solygambas/pen/eYdaJQx](https://codepen.io/solygambas/pen/eYdaJQx).

A image grid based on [50 Projects In 50 Days - HTML, CSS & JavaScript](https://www.udemy.com/course/50-projects-50-days/) by Brad Traversy (2020).

---
Want to collaborate? [Hire me](https://solygambas.github.io/)

[Twitter](https://twitter.com/solygambas) | [GitHub](https://github.com/solygambas) | [Dribbble](https://dribbble.com/solygambas)